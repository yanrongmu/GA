library(testthat)

test_check("GA")